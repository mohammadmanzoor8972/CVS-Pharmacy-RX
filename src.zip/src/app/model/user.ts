export class User  {
  debugInfo: string;
  firstName: string;
  id: number;
  lastName: string;
  password: string;
  username: string;
}
