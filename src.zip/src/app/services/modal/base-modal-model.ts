export class BaseModalModel {
   public isVisible: boolean;

    constructor(visible: boolean) {
        this.isVisible = visible;
    }
}
