export const environment = {
  production: true,

  spaceId: 'ntlw4jcg6rt2',
  location: 'en-US',
  accessToken: '1cb959fa03d54d3a9d14bef3cb40c76c9e59b9103aa7b21d84cceab9d6f3f502',
  gatewayToken: '36245312-42bb-3443-b240-d71ae01ac1ee',
  cacheCms: false,
  cacheExpiration: 3600,
  gatewayURL: 'https://rxreload-qa.incomm.com/rxreload/'
};
