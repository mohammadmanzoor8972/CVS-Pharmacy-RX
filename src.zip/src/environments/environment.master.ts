export const environment = {
  production: true,

  spaceId: 'CHANGEME',
  location: 'en-US',
  accessToken: 'CHANGEME',
  gatewayToken: '36245312-42bb-3443-b240-d71ae01ac1ee',
  cacheCms: true,
  cacheExpiration: 3600,
  gatewayURL: 'http://services.incommgatewayuat.com/v1/api/1.0/fsapi/master'


};
